
package com.webservice;


public interface HelloWorld {

	

	public String getHelloWorldAsString(String str);

}
