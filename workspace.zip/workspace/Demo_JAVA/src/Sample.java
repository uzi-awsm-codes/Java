// java.lang is default
public class Sample
{
public static void main(String[] s)
{
System.out.println("Hello");
}
}

class First{}

class Second{}