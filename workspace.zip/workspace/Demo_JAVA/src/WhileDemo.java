public class WhileDemo {

public static void main(String[] args) {
// TODO Auto-generated method stub
int n=5;
int i=1;
while(i<=n)
{
System.out.println("while loop="+i);
//i++;
}
do
{
System.out.println("do while loop="+i);
i++;
}while(i<=n);

}

}